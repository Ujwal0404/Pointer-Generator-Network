<html>
<head>
<title>dummy title</title>
</head>
<body bgcolor="white">
<a name="1">[1]</a> <a href="#1" id=1>Cambodia King Norodom Sihanouk praised formation of a coalition of the Countries top two political parties, leaving strongman Hun Sen as Prime Minister and opposition leader Prince Norodom Ranariddh president of the National Assembly.</a>
<a name="2">[2]</a> <a href="#2" id=2>The announcement comes after months of bitter argument following the failure of any party to attain the required quota to form a government.</a>
<a name="3">[3]</a> <a href="#3" id=3>Opposition leader Sam Rainey was seeking assurances that he and his party members would not be arrested if they return to Cambodia.</a>
<a name="4">[4]</a> <a href="#4" id=4>Rainey had been accused by Hun Sen of being behind an assassination attempt against him during massive street demonstrations in September.</a>
<a name="5">[5]</a> <a href="#5" id=5></a>
</body>
</html>