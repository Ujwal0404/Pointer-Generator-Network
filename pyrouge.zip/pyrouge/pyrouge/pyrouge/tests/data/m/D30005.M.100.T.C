<html>
<head>
<title>dummy title</title>
</head>
<body bgcolor="white">
<a name="1">[1]</a> <a href="#1" id=1>In the aftermath of the almost simultaneous bombings of U.S. embassies in East Africa, much has been learned of the terrorist network put together and financed by Saudi billionaire Osama bin Laden.</a>
<a name="2">[2]</a> <a href="#2" id=2>Osama bin Laden, the mastermind of the bombings and U.S. cruise missile attack against a supposed terrorist camp in Afghanistan shortly after the bombings was an attempt not only to disrupt the terrorist network but to get bin Laden himself.</a>
<a name="3">[3]</a> <a href="#3" id=3>As the investigation into the bombings continues, more is being learned from seized computers and top aides turned informants.</a>
<a name="4">[4]</a> <a href="#4" id=4>Bin Laden remains in Afghanistan by permission of the Taliban.</a>
<a name="5">[5]</a> <a href="#5" id=5></a>
</body>
</html>